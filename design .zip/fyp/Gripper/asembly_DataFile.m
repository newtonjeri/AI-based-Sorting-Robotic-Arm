% Simscape(TM) Multibody(TM) version: 7.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(30).translation = [0.0 0.0 0.0];
smiData.RigidTransform(30).angle = 0.0;
smiData.RigidTransform(30).axis = [0.0 0.0 0.0];
smiData.RigidTransform(30).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 10.999999999999996];  % mm
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = 'B[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [24.50000000000141 31.20000000000001 -5.3290705182007514e-13];  % mm
smiData.RigidTransform(2).angle = 2.0943951023932068;  % rad
smiData.RigidTransform(2).axis = [0.57735026918961818 0.57735026918962928 -0.57735026918962995];
smiData.RigidTransform(2).ID = 'F[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-18.000000000000004 0 0];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-28.071642444849765 31.199999999999967 18.637902064603644];  % mm
smiData.RigidTransform(4).angle = 1.7177715174584076;  % rad
smiData.RigidTransform(4).axis = [0.86285620946101249 0.3574067443365968 -0.35740674433660002];
smiData.RigidTransform(4).ID = 'F[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-48.501000000000019 40.276480175933116 -13.918506301988625];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-2.4868995751603507e-13 1.1075584893660562e-12 -44.501000000001483];  % mm
smiData.RigidTransform(6).angle = 1.8858750092022974e-15;  % rad
smiData.RigidTransform(6).axis = [0.67531580829412785 0.7375286835561371 4.6964395991147309e-16];
smiData.RigidTransform(6).ID = 'F[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 120.00000000000001 -0.00099999999999406119];  % mm
smiData.RigidTransform(7).angle = 0;  % rad
smiData.RigidTransform(7).axis = [0 0 0];
smiData.RigidTransform(7).ID = 'B[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [7.1054273576010019e-14 -34.749999999999609 -1.9990000000016348];  % mm
smiData.RigidTransform(8).angle = 3.14159265358979;  % rad
smiData.RigidTransform(8).axis = [1 4.3210714573685071e-31 2.5569882992351437e-16];
smiData.RigidTransform(8).ID = 'F[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 27.999999998507747 -13.999999999999998];  % mm
smiData.RigidTransform(9).angle = 1.3877787807814457e-16;  % rad
smiData.RigidTransform(9).axis = [-1 0 -0];
smiData.RigidTransform(9).ID = 'B[Arm 03-1:-:Gripper Assembly_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-16.027034808415234 -4.8971874308770502 17.063572190704718];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931935;  % rad
smiData.RigidTransform(10).axis = [-0.5773502691896274 -0.57735026918962518 0.57735026918962484];
smiData.RigidTransform(10).ID = 'F[Arm 03-1:-:Gripper Assembly_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-16.499999999999972 0 -3.5000000000000031];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'B[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-22.99999999850596 18.050000000000352 16.499999999998685];  % mm
smiData.RigidTransform(12).angle = 2.0943951023932024;  % rad
smiData.RigidTransform(12).axis = [0.5773502691896194 0.57735026918962773 -0.57735026918962995];
smiData.RigidTransform(12).ID = 'F[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-4.9999999999999902 12.071067811865483 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(13).ID = 'B[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-5.2999999999968317 67.071067811869625 5.4999999999980886];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931793;  % rad
smiData.RigidTransform(14).axis = [0.5773502691896204 -0.57735026918963517 0.57735026918962185];
smiData.RigidTransform(14).ID = 'F[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-22.027034808415948 -1.3971874308772447 80.063572190701933];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Gripper Assembly_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-26.900000000007125 18.049999999999962 24.999999999995865];  % mm
smiData.RigidTransform(16).angle = 2.0943951023932224;  % rad
smiData.RigidTransform(16).axis = [0.57735026918960886 -0.57735026918963384 0.5773502691896345];
smiData.RigidTransform(16).ID = 'F[Gripper Assembly_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [13.799999999999979 53.000000000000007 5.5000000000000053];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-13.79999999999994 26.049999999999955 4.0962788716569776e-12];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931784;  % rad
smiData.RigidTransform(18).axis = [0.57735026918963672 0.57735026918962018 -0.57735026918962029];
smiData.RigidTransform(18).ID = 'F[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 0 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-3.4504328257056284e-13 -85.999999999999901 -1.5221548466769754e-13];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962618 -0.57735026918962484 -0.5773502691896264];
smiData.RigidTransform(20).ID = 'F[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [-26.742621699555617 0.10281256912278436 100.50287212412168];  % mm
smiData.RigidTransform(21).angle = 0.96249960049913064;  % rad
smiData.RigidTransform(21).axis = [0 1 0];
smiData.RigidTransform(21).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [5.1490497788388847 12.602812569122628 46.129212505273706];  % mm
smiData.RigidTransform(22).angle = 2.0571673925353462;  % rad
smiData.RigidTransform(22).axis = [1.4185897284246514e-16 1 1.3003739177225971e-16];
smiData.RigidTransform(22).ID = 'AssemblyGround[Gripper Assembly_r1-1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [18.934562836559518 12.602812569123046 100.3297751116008];  % mm
smiData.RigidTransform(23).angle = 2.188796489983607;  % rad
smiData.RigidTransform(23).axis = [0 1 0];
smiData.RigidTransform(23).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [25.068265020143464 4.1028125691227597 73.564542112000566];  % mm
smiData.RigidTransform(24).angle = 2.8538296584974083;  % rad
smiData.RigidTransform(24).axis = [0.69964598705106473 0.69964598705106495 0.14488266151159204];
smiData.RigidTransform(24).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [-32.127933035076026 12.602812569122241 73.577077394539174];  % mm
smiData.RigidTransform(25).angle = 2.8733469341379116;  % rad
smiData.RigidTransform(25).axis = [0.70064010157965562 -0.70064010157965562 -0.13493293192137923];
smiData.RigidTransform(25).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-26.742621699555325 16.602812569122825 100.50287212412168];  % mm
smiData.RigidTransform(26).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(26).axis = [0.88641709845745564 0 -0.46288738107909716];
smiData.RigidTransform(26).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-22.027034808415948 4.1028125691227881 80.063572190701933];  % mm
smiData.RigidTransform(27).angle = 0;  % rad
smiData.RigidTransform(27).axis = [0 0 0];
smiData.RigidTransform(27).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-22.905571503443884 12.602812569122241 63.284336518949516];  % mm
smiData.RigidTransform(28).angle = 2.1915741801411106;  % rad
smiData.RigidTransform(28).axis = [7.8967321405726769e-17 -1 -1.4696695928288035e-16];
smiData.RigidTransform(28).ID = 'AssemblyGround[Gripper Assembly_r1-1:gear1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [18.934562836558616 0.10281256912278436 100.32977511160067];  % mm
smiData.RigidTransform(29).angle = 2.1887964899836021;  % rad
smiData.RigidTransform(29).axis = [0 1 0];
smiData.RigidTransform(29).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [-115.9427519169993 -37.92213569619625 49.784985041606987];  % mm
smiData.RigidTransform(30).angle = 2.7019115661528357;  % rad
smiData.RigidTransform(30).axis = [0.028362873081056051 -0.99957758404151376 -0.0063404189387009213];
smiData.RigidTransform(30).ID = 'SixDofRigidTransform[Arm 01-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.064392689835693531;  % kg
smiData.Solid(1).CoM = [-0.13010640517118283 58.590055934236545 7.7687950238576224];  % mm
smiData.Solid(1).MoI = [110.15257046900956 9.2537956247527955 115.09551025859405];  % kg*mm^2
smiData.Solid(1).PoI = [0.13194957348981942 -0.022606570487793787 -0.66174652803562073];  % kg*mm^2
smiData.Solid(1).color = [0 0.25490196078431371 0.92156862745098034];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Arm 01*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.050268280661544686;  % kg
smiData.Solid(2).CoM = [0.027846765839261257 4.5353069242678217 5.4088533654566078];  % mm
smiData.Solid(2).MoI = [54.600837585879738 9.2867708786792367 58.148972217615935];  % kg*mm^2
smiData.Solid(2).PoI = [-0.28753241094282822 -5.4544814798145673e-05 -0.06958365695522227];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Arm 02 v3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.033876630295594158;  % kg
smiData.Solid(3).CoM = [-0.49032191241283091 20.358074512903947 -1.2918440697811483e-06];  % mm
smiData.Solid(3).MoI = [5.8482510929244178 6.0274552077711139 9.587808059329852];  % kg*mm^2
smiData.Solid(3).PoI = [6.4718830448078686e-07 1.567238968978029e-07 0.27277211248685718];  % kg*mm^2
smiData.Solid(3).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Servo Motor MG996R_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0071285815431194298;  % kg
smiData.Solid(4).CoM = [-0.42843487706856676 12.510643062129503 0];  % mm
smiData.Solid(4).MoI = [0.45814644939764348 0.4276508140193635 0.70781861394704559];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0.035781849855651117];  % kg*mm^2
smiData.Solid(4).color = [0.12156862745098039 0.25490196078431371 1];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Servo Motor Micro  9g*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.00079876241318469095;  % kg
smiData.Solid(5).CoM = [15.500000000000007 2 0];  % mm
smiData.Solid(5).MoI = [0.0036325042236300988 0.10442422565960366 0.10292175453779941];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'grip link 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.0025658596693438522;  % kg
smiData.Solid(6).CoM = [-15.802287599926878 2 0.1399995313062786];  % mm
smiData.Solid(6).MoI = [0.096871414429773942 0.44616255154541529 0.35613342956722494];  % kg*mm^2
smiData.Solid(6).PoI = [0 0.044672222615650257 0];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'gear2_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.0053974701398930734;  % kg
smiData.Solid(7).CoM = [4.2500225915138357 9.513147651742198 -31.889976021591909];  % mm
smiData.Solid(7).MoI = [1.7139108532223843 1.5958276983903421 0.18307767030588401];  % kg*mm^2
smiData.Solid(7).PoI = [0.37341188434821887 6.5121955707659532e-06 1.2431071757242153e-05];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Gripper 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.0157214039263101;  % kg
smiData.Solid(8).CoM = [15.976607329816053 -3.1832399913282647 -39.448867575183598];  % mm
smiData.Solid(8).MoI = [7.2474438601419822 8.1157623325169244 2.5604582617981952];  % kg*mm^2
smiData.Solid(8).PoI = [-1.3641301898784308 -1.4285481948392436 -0.35034739686203431];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Gripper base_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.0026416132846297422;  % kg
smiData.Solid(9).CoM = [-4.5275913705687678 2 -0.60196930727362119];  % mm
smiData.Solid(9).MoI = [0.090046111646969532 0.44723966749329935 0.3642378579386758];  % kg*mm^2
smiData.Solid(9).PoI = [0 -0.0092574084887821796 0];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'gear1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.4638711806896591;  % kg
smiData.Solid(10).CoM = [0.00033070895600116547 51.365620594267369 -0.00060513768513946378];  % mm
smiData.Solid(10).MoI = [1400.6242624749952 2061.2568834285585 1473.1063207934212];  % kg*mm^2
smiData.Solid(10).PoI = [-0.013857222560408033 -0.0036016635968550942 0.0075729998638912046];  % kg*mm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'Part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.016499409121932894;  % kg
smiData.Solid(11).CoM = [0.045879907338241946 17.841068460271106 -5.2646318752902044];  % mm
smiData.Solid(11).MoI = [3.9122057893399464 2.612439912794732 5.0223428677045492];  % kg*mm^2
smiData.Solid(11).PoI = [0.57578925685915294 -0.0039826478484937568 0.011582795799652899];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Arm 03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.068038308291964195;  % kg
smiData.Solid(12).CoM = [-6.4346174922233264 17.289415162555223 -1.3719889444740436];  % mm
smiData.Solid(12).MoI = [58.133187548494583 54.676389153981759 45.017727888450807];  % kg*mm^2
smiData.Solid(12).PoI = [6.2427453291760617 -0.64175688336673276 5.1776609631200303];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'Waist*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(5).Rz.Pos = 0.0;
smiData.RevoluteJoint(5).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = -93.250647125017665;  % deg
smiData.RevoluteJoint(1).ID = '[Waist-1:-:Arm 01-1]';

smiData.RevoluteJoint(2).Rz.Pos = -153.47695691692428;  % deg
smiData.RevoluteJoint(2).ID = '[Arm 01-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(3).Rz.Pos = 131.67775704609866;  % deg
smiData.RevoluteJoint(3).ID = '[Arm 03-1:-:Gripper Assembly_r1-1]';

smiData.RevoluteJoint(4).Rz.Pos = -44.585105944281906;  % deg
smiData.RevoluteJoint(4).ID = '[Arm 03-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(5).Rz.Pos = 115.20217666883748;  % deg
smiData.RevoluteJoint(5).ID = '[Part1-1:-:Waist-1]';

