function varargout = guiarm(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @guiarm_OpeningFcn, ...
                   'gui_OutputFcn',  @guiarm_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);4
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before guiarm is made visible.
function guiarm_OpeningFcn(hObject, eventdata, handles, varargin)

handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes guiarm wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = guiarm_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;
 


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=get(handles.slider1, 'value');
set(handles.edit2, 'string', num2str(theta1));
theta2=get(handles.slider2, 'value');
set(handles.edit3, 'string', num2str(theta2));
theta3=get(handles.slider3, 'value');
set(handles.edit4, 'string', num2str(theta3));
theta4=get(handles.slider4, 'value');
set(handles.edit5, 'string', num2str(theta4));
theta5=get(handles.slider5, 'value');
set(handles.edit6, 'string', num2str(theta5));

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);
set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));


function slider1_CreateFcn(hObject, eventdata, handles)

if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=get(handles.slider1, 'value');
set(handles.edit2, 'string', num2str(theta1));
theta2=get(handles.slider2, 'value');
set(handles.edit3, 'string', num2str(theta2));
theta3=get(handles.slider3, 'value');
set(handles.edit4, 'string', num2str(theta3));
theta4=get(handles.slider4, 'value');
set(handles.edit5, 'string', num2str(theta4));
theta5=get(handles.slider5, 'value');
set(handles.edit6, 'string', num2str(theta5));

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);
set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)

if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=get(handles.slider1, 'value');
set(handles.edit2, 'string', num2str(theta1));
theta2=get(handles.slider2, 'value');
set(handles.edit3, 'string', num2str(theta2));
theta3=get(handles.slider3, 'value');
set(handles.edit4, 'string', num2str(theta3));
theta4=get(handles.slider4, 'value');
set(handles.edit5, 'string', num2str(theta4));
theta5=get(handles.slider5, 'value');
set(handles.edit6, 'string', num2str(theta5));

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);
set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)

if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=get(handles.slider1, 'value');
set(handles.edit2, 'string', num2str(theta1));
theta2=get(handles.slider2, 'value');
set(handles.edit3, 'string', num2str(theta2));
theta3=get(handles.slider3, 'value');
set(handles.edit4, 'string', num2str(theta3));
theta4=get(handles.slider4, 'value');
set(handles.edit5, 'string', num2str(theta4));
theta5=get(handles.slider5, 'value');
set(handles.edit6, 'string', num2str(theta5));

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);
set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=get(handles.slider1, 'value');
set(handles.edit2, 'string', num2str(theta1));
theta2=get(handles.slider2, 'value');
set(handles.edit3, 'string', num2str(theta2));
theta3=get(handles.slider3, 'value');
set(handles.edit4, 'string', num2str(theta3));
theta4=get(handles.slider4, 'value');
set(handles.edit5, 'string', num2str(theta4));
theta5=get(handles.slider5, 'value');
set(handles.edit6, 'string', num2str(theta5));

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);
set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));


% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)
px_inv=get(handles.slider6,'value');
set(handles.edit10,'string',num2str(px_inv));


% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider8_Callback(hObject, eventdata, handles)
pz_inv=get(handles.slider8,'value');
set(handles.edit12,'string',num2str(pz_inv));

% --- Executes during object creation, after setting all properties.
function slider8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider7_Callback(hObject, eventdata, handles)
py_inv=get(handles.slider7,'value');
set(handles.edit11,'string',num2str(py_inv));

% --- Executes during object creation, after setting all properties.
function slider7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
ModelName= 'assemblyfinal';
open_system(ModelName);
set_param(ModelName, 'BlockReduction','off');
set_param(ModelName, 'StopTime','inf');
set_param(ModelName, 'simulationMode','normal');

set_param(ModelName, 'StartFcn','1');
set_param(ModelName, 'Simulationcommand','start');

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
ModelName='assemblyfinal';
global var;
L1=119; L2=134.5; L3=81.8; L4=26.6; L5=77.9;
a1=L1;
a2=L2;
a3=L3;
a4=L4;
a5=L5;

%get the angle
theta1=0;
theta2=0;
theta3=0;
theta4=0;
theta5=0;

%connect to simulink
set_param ([ModelName '/Slider Gain'], 'Gain' ,num2str(theta1));
ser_param ([ModelName '/Slider Gain1'], 'Gain' ,num2str(theta2));
ser_param ([ModelName '/Slider Gain2'], 'Gain' ,num2str(theta3));
ser_param ([ModelName '/Slider Gain3'], 'Gain' ,num2str(theta4));
ser_param ([ModelName '/Slider Gain4'], 'Gain' ,num2str(theta5));

T0= [cosd(theta1) cosd(90)*sind(theta1) sind(90)*sind(theta1) 0*cosd(theta1);
    sind(theta1)  cosd(90)*cosd(theta1) -sind(90)*cosd(theta1) 0*sind(theta1);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T1= [cosd(theta2) cosd(0)*sind(theta2) sind(0)*sind(theta1) 119.03*cosd(theta1);
    sind(theta2)  cosd(0)*cosd(theta2) -sind(0)*cosd(theta1) 119.03*sind(theta2);
    0 sind(0) cosd(0) 0;
    0 0 0 1];
T2= [cosd(theta3+90) cosd(90)*sind(theta3+90) sind(90)*sind(theta3+90) 0*cosd(theta3+90);
    sind(theta3+90)  cosd(90)*cosd(theta3+90) -sind(90)*cosd(theta3+90) 0*sind(theta3+90);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T3= [cosd(theta4) cosd(-90)*sind(theta4) sind(-90)*sind(theta4) 0*cosd(theta4);
    sind(theta4)  cosd(-90)*cosd(theta4) -sind(-90)*cosd(theta4) 0*sind(theta4);
    0 sind(-90) cosd(-90) 134.55;
    0 0 0 1];
T4= [cosd(theta5) cosd(90)*sind(theta5) sind(90)*sind(theta5) 0*cosd(theta5);
    sind(theta5)  cosd(90)*cosd(theta5) -sind(90)*cosd(theta5) 0*sind(theta5);
    0 sind(90) cosd(90) 0;
    0 0 0 1];
T5= [cosd(90) cosd(0)*sind(90) sind(0)*sind(90) 0*cosd(90);
    sind(90)  cosd(0)*cosd(90) -sind(0)*cosd(90) 0*sind(0);
    0 sind(0) cosd(0) 81.84;
    0 0 0 1];
HTM= T0*T1*T2*T3*T4*T5;

Px1=HTM(1,4);
Py1=HTM(2,4);
Pz1=HTM(1,4);

set(handles.slider1, 'value', theta1);
set(handles.slider2, 'value', theta2);
set(handles.slider3, 'value', theta3);
set(handles.slider4, 'value', theta4);
set(handles.slider5, 'value', theta5);

set(handles.edit2, 'string', num2str(theta1));
set(handles.edit3, 'string', num2str(theta2));
set(handles.edit4, 'string', num2str(theta3));
set(handles.edit5, 'string', num2str(theta4));
set(handles.edit6, 'string', num2str(theta5));

set(handles.edit10, 'string', num2str(Px1));
set(handles.edit11, 'string', num2str(Py1));
set(handles.edit12, 'string', num2str(Pz1));




% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
close;

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
close;
