% Simscape(TM) Multibody(TM) version: 7.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(50).translation = [0.0 0.0 0.0];
smiData.RigidTransform(50).angle = 0.0;
smiData.RigidTransform(50).axis = [0.0 0.0 0.0];
smiData.RigidTransform(50).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [31 4 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [13.000000000001055 -6.7359451350057498e-12 -4.9999999999996163];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931811;  % rad
smiData.RigidTransform(2).axis = [0.57735026918962085 -0.57735026918963483 0.57735026918962151];
smiData.RigidTransform(2).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [31.000000000001439 9.0000000000079865 -2.7426949600339867e-12];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931793;  % rad
smiData.RigidTransform(4).axis = [0.57735026918962029 -0.57735026918963539 0.57735026918962151];
smiData.RigidTransform(4).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [31.000000000004491 -3.4999999999942069 -3.2009950245992513e-12];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931775;  % rad
smiData.RigidTransform(6).axis = [0.57735026918961974 -0.57735026918963572 0.57735026918962173];
smiData.RigidTransform(6).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [13 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [30.999999999996302 7.4999999999898304 -5.1159076974727213e-12];  % mm
smiData.RigidTransform(8).angle = 2.0943951023932188;  % rad
smiData.RigidTransform(8).axis = [-0.5773502691896335 -0.57735026918962484 -0.57735026918961885];
smiData.RigidTransform(8).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-10.106342553831125 4 0];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [5.0000000000033893 12.499999999995167 -24.999999999995694];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931819;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962118 -0.57735026918963661 0.5773502691896194];
smiData.RigidTransform(10).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-5.3230678462266212 4.0000000000028022 -52.018532924372458];  % mm
smiData.RigidTransform(12).angle = 1.5953800614335352;  % rad
smiData.RigidTransform(12).axis = [-0.97571356780552221 0.15489195201852904 0.15489195201852216];
smiData.RigidTransform(12).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-3.9999999999985549 4.99999999999749 -4.9999999999973799];  % mm
smiData.RigidTransform(14).angle = 2.0943951023932077;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962484 0.57735026918962984 0.57735026918962262];
smiData.RigidTransform(14).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [31.899999999999999 0 -24.999999999999993];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-10.106342553835493 -8.4999999999923066 -3.4656721936698887e-12];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931762;  % rad
smiData.RigidTransform(16).axis = [0.57735026918961929 -0.57735026918963428 0.57735026918962362];
smiData.RigidTransform(16).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-40.593272041075799 0 4.01368041076661];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [8.4999999999884341 4.9999999999723954 -4.9999999999665157];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(18).axis = [0.57735026918962407 0.57735026918962573 0.5773502691896274];
smiData.RigidTransform(18).ID = 'F[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 4 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-1.1598721982863935e-11 4.9999999999793374 -26.999999999972509];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(20).axis = [-0.5773502691896254 -0.57735026918962651 0.5773502691896254];
smiData.RigidTransform(20).ID = 'F[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [8.5 4.9999999999999973 -26.999999999999996];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-2.7824084258376177e-11 9.4519947424494355e-12 -1.6399622154664562e-11];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931922;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962462 -0.57735026918962595 0.57735026918962673];
smiData.RigidTransform(22).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 4 0];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [8.5000000000027356 4.9999999999988578 -26.999999999994429];  % mm
smiData.RigidTransform(24).angle = 2.0943951023932104;  % rad
smiData.RigidTransform(24).axis = [0.57735026918962618 0.57735026918963062 0.5773502691896204];
smiData.RigidTransform(24).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [8.5 5.0000000000000044 -26.999999999999996];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-7.0020666295689046e-12 12.499999999993793 -1.1719436258421744e-11];  % mm
smiData.RigidTransform(26).angle = 2.0943951023931899;  % rad
smiData.RigidTransform(26).axis = [0.57735026918962384 -0.57735026918963206 0.57735026918962129];
smiData.RigidTransform(26).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 4 0];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [31.259645120332909 -4.4836701572990943e-12 -38.163237496114917];  % mm
smiData.RigidTransform(28).angle = 2.0943951023931882;  % rad
smiData.RigidTransform(28).axis = [0.57735026918962329 -0.57735026918963284 0.57735026918962107];
smiData.RigidTransform(28).ID = 'F[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [0 0 11.000000000000011];  % mm
smiData.RigidTransform(29).angle = 0;  % rad
smiData.RigidTransform(29).axis = [0 0 0];
smiData.RigidTransform(29).ID = 'B[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [24.499999999998018 31.200000000000216 2.8279600883251987e-12];  % mm
smiData.RigidTransform(30).angle = 2.0943951023932024;  % rad
smiData.RigidTransform(30).axis = [0.57735026918962185 0.57735026918962773 -0.57735026918962784];
smiData.RigidTransform(30).ID = 'F[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-17.999999999999996 0 0];  % mm
smiData.RigidTransform(31).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(31).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(31).ID = 'B[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-28.071642444851584 31.200000000000159 18.637902064604113];  % mm
smiData.RigidTransform(32).angle = 1.7177715174584021;  % rad
smiData.RigidTransform(32).axis = [0.86285620946101671 0.3574067443365932 -0.3574067443365937];
smiData.RigidTransform(32).ID = 'F[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [-48.500999999999983 40.276480175933131 -13.918506301988625];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(33).ID = 'B[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [-6.4659388954169117e-13 -2.5757174171303632e-13 -44.500999999999863];  % mm
smiData.RigidTransform(34).angle = 4.8114112203733501e-16;  % rad
smiData.RigidTransform(34).axis = [-0.46712475007827592 0.88419142037474474 -9.9362304606456257e-17];
smiData.RigidTransform(34).ID = 'F[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [0 27.999999998507775 -13.999999999999998];  % mm
smiData.RigidTransform(35).angle = 1.1102230246251565e-16;  % rad
smiData.RigidTransform(35).axis = [-1 0 -0];
smiData.RigidTransform(35).ID = 'B[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [6.0000000000015916 -9.0000000000057554 -63.000000000003169];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(36).axis = [-0.57735026918962595 -0.57735026918962595 0.57735026918962551];
smiData.RigidTransform(36).ID = 'F[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 -5.5000000000000329 0];  % mm
smiData.RigidTransform(37).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(37).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(37).ID = 'B[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [-26.900000000014323 18.050000000000296 25.000000000000753];  % mm
smiData.RigidTransform(38).angle = 2.0943951023931926;  % rad
smiData.RigidTransform(38).axis = [0.57735026918962773 -0.57735026918962473 0.57735026918962473];
smiData.RigidTransform(38).ID = 'F[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [0 120 -0.0010000000000010001];  % mm
smiData.RigidTransform(39).angle = 1.1102230246251565e-16;  % rad
smiData.RigidTransform(39).axis = [0 1 0];
smiData.RigidTransform(39).ID = 'B[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [-4.1353587221237831e-12 -34.750000000003062 -1.9989999999975474];  % mm
smiData.RigidTransform(40).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(40).axis = [1 -1.3373123166208019e-32 -2.1494991029781051e-16];
smiData.RigidTransform(40).ID = 'F[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [-16.499999999999993 0 -3.5000000000000031];  % mm
smiData.RigidTransform(41).angle = 0;  % rad
smiData.RigidTransform(41).axis = [0 0 0];
smiData.RigidTransform(41).ID = 'B[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-22.999999998507917 18.049999999999571 16.499999999999627];  % mm
smiData.RigidTransform(42).angle = 2.094395102393197;  % rad
smiData.RigidTransform(42).axis = [0.57735026918962473 0.57735026918962651 -0.57735026918962606];
smiData.RigidTransform(42).ID = 'F[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-5.0000000000000115 12.071067811865454 0];  % mm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [-5.2999999999995211 67.07106781186539 5.5000000000017373];  % mm
smiData.RigidTransform(44).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(44).axis = [0.5773502691896254 -0.57735026918962629 0.57735026918962562];
smiData.RigidTransform(44).ID = 'F[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [13.799999999999979 52.999999999999936 5.4999999999999769];  % mm
smiData.RigidTransform(45).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(45).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(45).ID = 'B[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [-13.80000000000018 26.049999999999415 -1.6608936448392342e-13];  % mm
smiData.RigidTransform(46).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(46).axis = [0.5773502691896254 0.57735026918962584 -0.57735026918962618];
smiData.RigidTransform(46).ID = 'F[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [0 0 0];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(47).ID = 'B[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [1.1314105004883199e-12 -85.999999999999986 -1.3369839947948359e-13];  % mm
smiData.RigidTransform(48).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(48).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(48).ID = 'F[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-140.65528607065161 -154.44236698097052 81.593161145651123];  % mm
smiData.RigidTransform(49).angle = 0;  % rad
smiData.RigidTransform(49).axis = [0 0 0];
smiData.RigidTransform(49).ID = 'RootGround[Part1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-22.027034808415891 4.1028125691227597 80.063572190702033];  % mm
smiData.RigidTransform(50).angle = 0;  % rad
smiData.RigidTransform(50).axis = [0 0 0];
smiData.RigidTransform(50).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper base_r1-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.46387118068965888;  % kg
smiData.Solid(1).CoM = [0.00033070895600116596 51.365620594267376 -0.00060513768514129011];  % mm
smiData.Solid(1).MoI = [1400.6242624749948 2061.256883428558 1473.1063207934212];  % kg*mm^2
smiData.Solid(1).PoI = [-0.013857222560413426 -0.0036016635968551137 0.0075729998638912029];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.0071285815431194298;  % kg
smiData.Solid(2).CoM = [-0.42843487706856676 12.510643062129503 0];  % mm
smiData.Solid(2).MoI = [0.45814644939764343 0.42765081401936345 0.70781861394704559];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0.035781849855651124];  % kg*mm^2
smiData.Solid(2).color = [0.12156862745098039 0.25490196078431371 1];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Servo Motor Micro  9g*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.033876630295594158;  % kg
smiData.Solid(3).CoM = [-0.4903219124128308 20.358074512903947 -1.2918440697939337e-06];  % mm
smiData.Solid(3).MoI = [5.8482510929244178 6.0274552077711139 9.5878080593298538];  % kg*mm^2
smiData.Solid(3).PoI = [6.4718830444811437e-07 1.5672389691108006e-07 0.27277211248685729];  % kg*mm^2
smiData.Solid(3).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Servo Motor MG996R_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0053974701398930717;  % kg
smiData.Solid(4).CoM = [4.2500225915138357 9.5131476517421962 -31.889976021591902];  % mm
smiData.Solid(4).MoI = [1.7139108532223843 1.5958276983903423 0.18307767030588401];  % kg*mm^2
smiData.Solid(4).PoI = [0.37341188434821887 6.5121955707659532e-06 1.2431071757242153e-05];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Gripper 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.0026416132846297426;  % kg
smiData.Solid(5).CoM = [-4.5275913705687678 2 -0.60196930727362141];  % mm
smiData.Solid(5).MoI = [0.090046111646969504 0.4472396674932993 0.36423785793867586];  % kg*mm^2
smiData.Solid(5).PoI = [0 -0.0092574084887821796 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'gear1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.00079876241318469084;  % kg
smiData.Solid(6).CoM = [15.500000000000007 2 0];  % mm
smiData.Solid(6).MoI = [0.0036325042236300983 0.10442422565960367 0.10292175453779942];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'grip link 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.0025658596693438518;  % kg
smiData.Solid(7).CoM = [-15.802287599926874 2 0.13999953130627879];  % mm
smiData.Solid(7).MoI = [0.096871414429773942 0.44616255154541512 0.35613342956722482];  % kg*mm^2
smiData.Solid(7).PoI = [0 0.044672222615650264 0];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'gear2_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.0157214039263101;  % kg
smiData.Solid(8).CoM = [15.976607329816053 -3.1832399913282656 -39.448867575183598];  % mm
smiData.Solid(8).MoI = [7.2474438601419822 8.1157623325169261 2.5604582617981952];  % kg*mm^2
smiData.Solid(8).PoI = [-1.3641301898784308 -1.4285481948392438 -0.35034739686203425];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Gripper base_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.016499409121932887;  % kg
smiData.Solid(9).CoM = [0.045879907338242321 17.841068460271099 -5.2646318752902062];  % mm
smiData.Solid(9).MoI = [3.912205789339946 2.612439912794732 5.0223428677045492];  % kg*mm^2
smiData.Solid(9).PoI = [0.57578925685915294 -0.003982647848493775 0.01158279579965278];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'Arm 03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.068038308291964195;  % kg
smiData.Solid(10).CoM = [-6.4346174922233237 17.289415162555223 -1.371988944474043];  % mm
smiData.Solid(10).MoI = [58.133187548494583 54.676389153981752 45.017727888450807];  % kg*mm^2
smiData.Solid(10).PoI = [6.24274532917606 -0.64175688336673375 5.1776609631200285];  % kg*mm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'Waist*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.050268280661544686;  % kg
smiData.Solid(11).CoM = [0.027846765839261257 4.535306924267819 5.4088533654566078];  % mm
smiData.Solid(11).MoI = [54.600837585879745 9.2867708786792367 58.148972217615942];  % kg*mm^2
smiData.Solid(11).PoI = [-0.287532410942828 -5.4544814798145673e-05 -0.069583656955222187];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Arm 02 v3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.064392689835693517;  % kg
smiData.Solid(12).CoM = [-0.13010640517118224 58.590055934236545 7.7687950238576207];  % mm
smiData.Solid(12).MoI = [110.15257046900956 9.2537956247527955 115.09551025859403];  % kg*mm^2
smiData.Solid(12).PoI = [0.1319495734898195 -0.022606570487794339 -0.66174652803562295];  % kg*mm^2
smiData.Solid(12).color = [0 0.25490196078431371 0.92156862745098034];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'Arm 01*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(6).Rz.Pos = 0.0;
smiData.CylindricalJoint(6).Pz.Pos = 0.0;
smiData.CylindricalJoint(6).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(1).Rz.Pos = -129.63565883886986;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.CylindricalJoint(2).Rz.Pos = 129.11245665333576;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-4]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = -129.83018712258379;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(4).Rz.Pos = 63.037417395358062;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[Gripper Assembly_r1-1:grip link 1_r1-2:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(5).Rz.Pos = 119.17294178010054;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(5).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(6).Rz.Pos = -60.827058219901481;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-2:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(1).Rz.Pos = 0.0;
smiData.PlanarJoint(1).Px.Pos = 0.0;
smiData.PlanarJoint(1).Py.Pos = 0.0;
smiData.PlanarJoint(1).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 101.25188450779437;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-3:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(11).Rz.Pos = 0.0;
smiData.RevoluteJoint(11).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 50.887543346666249;  % deg
smiData.RevoluteJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -129.63565883886844;  % deg
smiData.RevoluteJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-2]';

smiData.RevoluteJoint(3).Rz.Pos = -61.544788689149513;  % deg
smiData.RevoluteJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

smiData.RevoluteJoint(4).Rz.Pos = -122.12924545486533;  % deg
smiData.RevoluteJoint(4).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:gear2_r1-1]';

smiData.RevoluteJoint(5).Rz.Pos = -55.531004011354966;  % deg
smiData.RevoluteJoint(5).ID = '[Gripper Assembly_r1-1:gear2_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

smiData.RevoluteJoint(6).Rz.Pos = -63.037417395359498;  % deg
smiData.RevoluteJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.RevoluteJoint(7).Rz.Pos = -122.1590603774364;  % deg
smiData.RevoluteJoint(7).ID = '[Waist-1:-:Arm 01-1]';

smiData.RevoluteJoint(8).Rz.Pos = -141.56334404319554;  % deg
smiData.RevoluteJoint(8).ID = '[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(9).Rz.Pos = 152.79533642744349;  % deg
smiData.RevoluteJoint(9).ID = '[Arm 01-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(10).Rz.Pos = 27.805952598755567;  % deg
smiData.RevoluteJoint(10).ID = '[Arm 03-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(11).Rz.Pos = 116.34158006980427;  % deg
smiData.RevoluteJoint(11).ID = '[Part1-1:-:Waist-1]';

