% Simscape(TM) Multibody(TM) version: 7.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(30).translation = [0.0 0.0 0.0];
smiData.RigidTransform(30).angle = 0.0;
smiData.RigidTransform(30).axis = [0.0 0.0 0.0];
smiData.RigidTransform(30).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 11.000000000000004];  % mm
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = 'B[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [24.49999999999897 31.200000000000429 -3.3395508580724709e-13];  % mm
smiData.RigidTransform(2).angle = 2.0943951023932104;  % rad
smiData.RigidTransform(2).axis = [0.57735026918961652 0.57735026918963039 -0.57735026918963039];
smiData.RigidTransform(2).ID = 'F[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-18.000000000000011 0 0];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-28.071642444851125 31.200000000000585 18.637902064605772];  % mm
smiData.RigidTransform(4).angle = 1.7177715174584087;  % rad
smiData.RigidTransform(4).axis = [0.86285620946101138 0.35740674433659964 -0.35740674433660019];
smiData.RigidTransform(4).ID = 'F[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-48.501000000000019 40.276480175933123 -13.918506301988625];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-1.9539925233402755e-13 8.7885254629327392e-13 -44.500999999999927];  % mm
smiData.RigidTransform(6).angle = 2.7387674475997509e-15;  % rad
smiData.RigidTransform(6).axis = [0.26442817476477032 -0.9644053817718834 -3.4921469786069003e-16];
smiData.RigidTransform(6).ID = 'F[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 119.99999999999999 -0.00099999999999753064];  % mm
smiData.RigidTransform(7).angle = 1.3877787807814457e-16;  % rad
smiData.RigidTransform(7).axis = [-0 -1 0];
smiData.RigidTransform(7).ID = 'B[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [8.0868645113696402e-13 -34.750000000002288 -1.9990000000000032];  % mm
smiData.RigidTransform(8).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(8).axis = [-1 -2.473739405664566e-31 7.349726725359338e-16];
smiData.RigidTransform(8).ID = 'F[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 27.999999998507747 -14.000000000000005];  % mm
smiData.RigidTransform(9).angle = 0;  % rad
smiData.RigidTransform(9).axis = [0 0 0];
smiData.RigidTransform(9).ID = 'B[Arm 03-1:-:Gripper Assembly_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-16.027034808416083 -4.8971874308775529 17.063572190701844];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(10).axis = [-0.57735026918962595 -0.57735026918962584 0.57735026918962551];
smiData.RigidTransform(10).ID = 'F[Arm 03-1:-:Gripper Assembly_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-16.500000000000014 0 -3.5000000000000102];  % mm
smiData.RigidTransform(11).angle = 1.2490009027033011e-16;  % rad
smiData.RigidTransform(11).axis = [1 0 0];
smiData.RigidTransform(11).ID = 'B[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-22.999999998505576 18.050000000000217 16.499999999998906];  % mm
smiData.RigidTransform(12).angle = 2.0943951023932077;  % rad
smiData.RigidTransform(12).axis = [0.57735026918961696 0.57735026918962973 -0.57735026918963073];
smiData.RigidTransform(12).ID = 'F[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-5.0000000000000187 12.071067811865454 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-5.300000000000157 67.071067811865589 5.499999999999897];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931997;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962729 -0.57735026918962284 0.57735026918962729];
smiData.RigidTransform(14).ID = 'F[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-22.027034808415916 -1.3971874308772447 80.063572190701962];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Gripper Assembly_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-26.900000000007967 18.049999999999734 24.99999999999886];  % mm
smiData.RigidTransform(16).angle = 2.0943951023932303;  % rad
smiData.RigidTransform(16).axis = [0.57735026918960297 -0.57735026918963717 0.57735026918963717];
smiData.RigidTransform(16).ID = 'F[Gripper Assembly_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [13.799999999999994 52.999999999999993 5.5000000000000053];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-13.800000000001496 26.049999999999859 -5.3561599600016052e-12];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931717;  % rad
smiData.RigidTransform(18).axis = [0.57735026918964105 0.57735026918961851 -0.57735026918961774];
smiData.RigidTransform(18).ID = 'F[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 0 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [0 -85.999999999999986 0];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(20).ID = 'F[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [-22.027034808415916 4.1028125691227322 80.063572190701962];  % mm
smiData.RigidTransform(21).angle = 0;  % rad
smiData.RigidTransform(21).axis = [0 0 0];
smiData.RigidTransform(21).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [18.934562836558641 0.1028125691227566 100.32977511160071];  % mm
smiData.RigidTransform(22).angle = 2.1887964899836025;  % rad
smiData.RigidTransform(22).axis = [4.8326912009481989e-17 1 0];
smiData.RigidTransform(22).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-22.905571503443866 12.602812569122241 63.284336518949559];  % mm
smiData.RigidTransform(23).angle = 2.1915741801411102;  % rad
smiData.RigidTransform(23).axis = [4.3870734114292665e-17 -1 -7.0193174582868258e-17];
smiData.RigidTransform(23).ID = 'AssemblyGround[Gripper Assembly_r1-1:gear1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-26.742621699555599 0.10281256912272885 100.50287212412174];  % mm
smiData.RigidTransform(24).angle = 0.96249960049913064;  % rad
smiData.RigidTransform(24).axis = [0 1 0];
smiData.RigidTransform(24).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [25.068265020143482 4.1028125691227322 73.564542112000595];  % mm
smiData.RigidTransform(25).angle = 2.8538296584974083;  % rad
smiData.RigidTransform(25).axis = [0.69964598705106473 0.69964598705106473 0.14488266151159207];
smiData.RigidTransform(25).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-32.127933035076033 12.602812569122213 73.577077394539231];  % mm
smiData.RigidTransform(26).angle = 2.8733469341379116;  % rad
smiData.RigidTransform(26).axis = [0.70064010157965573 -0.70064010157965562 -0.1349329319213792];
smiData.RigidTransform(26).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [18.93456283655955 12.602812569122989 100.32977511160087];  % mm
smiData.RigidTransform(27).angle = 2.1887964899836065;  % rad
smiData.RigidTransform(27).axis = [0 1 0];
smiData.RigidTransform(27).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-26.742621699555308 16.602812569122801 100.50287212412172];  % mm
smiData.RigidTransform(28).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(28).axis = [0.88641709845745564 0 -0.46288738107909722];
smiData.RigidTransform(28).ID = 'AssemblyGround[Gripper Assembly_r1-1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [5.1490497788389042 12.602812569122602 46.129212505273742];  % mm
smiData.RigidTransform(29).angle = 2.0571673925353462;  % rad
smiData.RigidTransform(29).axis = [1.3121954987928024e-16 1 9.4572648561643416e-17];
smiData.RigidTransform(29).ID = 'AssemblyGround[Gripper Assembly_r1-1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [-66.454783510293339 -184.25915316479026 19.434802200730246];  % mm
smiData.RigidTransform(30).angle = 0;  % rad
smiData.RigidTransform(30).axis = [0 0 0];
smiData.RigidTransform(30).ID = 'RootGround[Part1-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.46387118068965888;  % kg
smiData.Solid(1).CoM = [0.00033070895600094668 51.365620594267369 -0.0006051376851392375];  % mm
smiData.Solid(1).MoI = [1400.6242624749952 2061.256883428558 1473.1063207934212];  % kg*mm^2
smiData.Solid(1).PoI = [-0.013857222560407341 -0.0036016635968551132 0.0075729998638832388];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.068038308291964195;  % kg
smiData.Solid(2).CoM = [-6.4346174922233228 17.289415162555223 -1.3719889444740434];  % mm
smiData.Solid(2).MoI = [58.133187548494583 54.676389153981752 45.017727888450814];  % kg*mm^2
smiData.Solid(2).PoI = [6.2427453291760608 -0.64175688336673442 5.1776609631200277];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Waist*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.033876630295594151;  % kg
smiData.Solid(3).CoM = [-0.49032191241283102 20.358074512903947 -1.2918440697332416e-06];  % mm
smiData.Solid(3).MoI = [5.8482510929244169 6.0274552077711148 9.5878080593298538];  % kg*mm^2
smiData.Solid(3).PoI = [6.4718830448954815e-07 1.5672389689729703e-07 0.27277211248685745];  % kg*mm^2
smiData.Solid(3).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Servo Motor MG996R_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.050268280661544686;  % kg
smiData.Solid(4).CoM = [0.027846765839261125 4.535306924267819 5.4088533654566078];  % mm
smiData.Solid(4).MoI = [54.600837585879745 9.2867708786792367 58.148972217615942];  % kg*mm^2
smiData.Solid(4).PoI = [-0.28753241094282783 -5.4544814798143254e-05 -0.069583656955222117];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Arm 02 v3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.01649940912193289;  % kg
smiData.Solid(5).CoM = [0.045879907338241821 17.841068460271103 -5.2646318752902053];  % mm
smiData.Solid(5).MoI = [3.9122057893399451 2.6124399127947315 5.0223428677045492];  % kg*mm^2
smiData.Solid(5).PoI = [0.57578925685915294 -0.0039826478484937256 0.01158279579965292];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'Arm 03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.0071285815431194298;  % kg
smiData.Solid(6).CoM = [-0.4284348770685667 12.510643062129503 0];  % mm
smiData.Solid(6).MoI = [0.45814644939764348 0.4276508140193635 0.70781861394704559];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0.035781849855651131];  % kg*mm^2
smiData.Solid(6).color = [0.12156862745098039 0.25490196078431371 1];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Servo Motor Micro  9g*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.064392689835693503;  % kg
smiData.Solid(7).CoM = [-0.13010640517118249 58.590055934236545 7.7687950238576189];  % mm
smiData.Solid(7).MoI = [110.15257046900956 9.2537956247527955 115.09551025859405];  % kg*mm^2
smiData.Solid(7).PoI = [0.13194957348981856 -0.022606570487793815 -0.66174652803562084];  % kg*mm^2
smiData.Solid(7).color = [0 0.25490196078431371 0.92156862745098034];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Arm 01*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.0157214039263101;  % kg
smiData.Solid(8).CoM = [15.97660732981605 -3.1832399913282656 -39.448867575183598];  % mm
smiData.Solid(8).MoI = [7.2474438601419822 8.1157623325169261 2.5604582617981957];  % kg*mm^2
smiData.Solid(8).PoI = [-1.364130189878431 -1.4285481948392436 -0.35034739686203442];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Gripper base_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.00079876241318469095;  % kg
smiData.Solid(9).CoM = [15.500000000000007 2 0];  % mm
smiData.Solid(9).MoI = [0.0036325042236300988 0.10442422565960369 0.10292175453779942];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'grip link 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.0026416132846297426;  % kg
smiData.Solid(10).CoM = [-4.5275913705687669 2 -0.60196930727362152];  % mm
smiData.Solid(10).MoI = [0.090046111646969504 0.44723966749329935 0.3642378579386758];  % kg*mm^2
smiData.Solid(10).PoI = [0 -0.0092574084887821814 0];  % kg*mm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'gear1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.0053974701398930717;  % kg
smiData.Solid(11).CoM = [4.2500225915138357 9.5131476517421962 -31.889976021591902];  % mm
smiData.Solid(11).MoI = [1.7139108532223843 1.5958276983903421 0.18307767030588401];  % kg*mm^2
smiData.Solid(11).PoI = [0.37341188434821881 6.5121955707659532e-06 1.2431071757242153e-05];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Gripper 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.0025658596693438522;  % kg
smiData.Solid(12).CoM = [-15.802287599926874 2 0.13999953130627876];  % mm
smiData.Solid(12).MoI = [0.096871414429773914 0.44616255154541512 0.35613342956722482];  % kg*mm^2
smiData.Solid(12).PoI = [0 0.044672222615650257 0];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'gear2_r1*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(5).Rz.Pos = 0.0;
smiData.RevoluteJoint(5).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = -69.280301160194782;  % deg
smiData.RevoluteJoint(1).ID = '[Waist-1:-:Arm 01-1]';

smiData.RevoluteJoint(2).Rz.Pos = 154.56714199042443;  % deg
smiData.RevoluteJoint(2).ID = '[Arm 01-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(3).Rz.Pos = 122.71029408936903;  % deg
smiData.RevoluteJoint(3).ID = '[Arm 03-1:-:Gripper Assembly_r1-1]';

smiData.RevoluteJoint(4).Rz.Pos = 165.73704215238502;  % deg
smiData.RevoluteJoint(4).ID = '[Arm 03-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(5).Rz.Pos = -102.78855540452922;  % deg
smiData.RevoluteJoint(5).ID = '[Part1-1:-:Waist-1]';

