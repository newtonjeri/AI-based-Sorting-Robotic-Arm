% Simscape(TM) Multibody(TM) version: 7.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(50).translation = [0.0 0.0 0.0];
smiData.RigidTransform(50).angle = 0.0;
smiData.RigidTransform(50).axis = [0.0 0.0 0.0];
smiData.RigidTransform(50).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [31 4 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [13.000000000030962 -9.9094066285942972e-12 -4.9999999999480451];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(2).axis = [0.5773502691896254 -0.57735026918962573 0.57735026918962618];
smiData.RigidTransform(2).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [30.999999999664844 9.0000000001059135 -1.0454215271238354e-10];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(4).axis = [0.5773502691896254 -0.57735026918962595 0.57735026918962595];
smiData.RigidTransform(4).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [30.99999999968211 -3.4999999998963194 -9.9625196980923647e-11];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(6).axis = [0.5773502691896254 -0.57735026918962595 0.57735026918962584];
smiData.RigidTransform(6).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [13 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [31.000000000033079 7.4999999999942197 4.8068216074170778e-11];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962562 -0.57735026918962473 -0.57735026918962684];
smiData.RigidTransform(8).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-10.106342553831125 4 0];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [5.00000000003606 12.499999999995408 -24.999999999937408];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962529 -0.57735026918962506 0.57735026918962684];
smiData.RigidTransform(10).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-5.6969427300573763 4.0000000001063425 -48.177220852913621];  % mm
smiData.RigidTransform(12).angle = 1.6188265865774638;  % rad
smiData.RigidTransform(12).axis = [-0.9530873350218656 0.21403800108966567 0.21403800108966287];
smiData.RigidTransform(12).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-4.0000000000015881 4.99999999999718 -5.0000000000543263];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962562 0.57735026918962595 0.57735026918962573];
smiData.RigidTransform(14).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [31.899999999999999 0 -24.999999999999993];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-10.106342554174823 -8.4999999998891393 -6.9472427810524096e-11];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(16).axis = [0.57735026918962562 -0.57735026918962629 0.57735026918962529];
smiData.RigidTransform(16).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-40.593272041075799 0 4.01368041076661];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [8.4999999998970992 4.9999999997098366 -4.9999999997363993];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(18).axis = [0.57735026918962595 0.57735026918962595 0.57735026918962529];
smiData.RigidTransform(18).ID = 'F[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 4 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-9.7955421551887412e-11 4.9999999997042597 -26.999999999744801];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962573 -0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(20).ID = 'F[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [8.5 4.9999999999999973 -26.999999999999996];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-3.439582848896013e-10 9.5724317361600943e-11 -1.4213388710052791e-10];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962562 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(22).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 4 0];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [8.5000000000037765 4.9999999999945253 -27.000000000044345];  % mm
smiData.RigidTransform(24).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(24).axis = [0.57735026918962518 0.57735026918962606 0.57735026918962618];
smiData.RigidTransform(24).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [8.5 5.0000000000000044 -26.999999999999996];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [2.4825567089151794e-11 12.500000000000352 3.405830495510527e-11];  % mm
smiData.RigidTransform(26).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(26).axis = [0.57735026918962562 -0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(26).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 4 0];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [25.044248746132961 9.8010367169388848e-11 -38.569511767278925];  % mm
smiData.RigidTransform(28).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(28).axis = [0.57735026918962618 -0.57735026918962673 0.5773502691896244];
smiData.RigidTransform(28).ID = 'F[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [0 0 11.000000000000011];  % mm
smiData.RigidTransform(29).angle = 1.6653345369377348e-16;  % rad
smiData.RigidTransform(29).axis = [1 0 0];
smiData.RigidTransform(29).ID = 'B[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [24.499999999999154 31.200000000000049 -3.3750779948604759e-13];  % mm
smiData.RigidTransform(30).angle = 2.0943951023932033;  % rad
smiData.RigidTransform(30).axis = [0.57735026918962173 0.57735026918962751 -0.57735026918962795];
smiData.RigidTransform(30).ID = 'F[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-18.000000000000014 0 0];  % mm
smiData.RigidTransform(31).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(31).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(31).ID = 'B[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-28.071642444851996 31.199999999998973 18.637902064603267];  % mm
smiData.RigidTransform(32).angle = 1.717771517458403;  % rad
smiData.RigidTransform(32).axis = [0.8628562094610156 0.35740674433659453 -0.35740674433659492];
smiData.RigidTransform(32).ID = 'F[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [-48.501000000000019 40.276480175933123 -13.918506301988625];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(33).ID = 'B[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [2.7391422463551862e-12 -6.1017857433398603e-12 -44.500999999999777];  % mm
smiData.RigidTransform(34).angle = 5.0615889881746824e-16;  % rad
smiData.RigidTransform(34).axis = [0.148279958325927 0.98894542516706219 3.71117694906664e-17];
smiData.RigidTransform(34).ID = 'F[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [0 27.999999998507828 -13.999999999999972];  % mm
smiData.RigidTransform(35).angle = 0;  % rad
smiData.RigidTransform(35).axis = [0 0 0];
smiData.RigidTransform(35).ID = 'B[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [5.9999999999967244 -9.0000000000045759 -63.000000000002714];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(36).axis = [-0.5773502691896254 -0.57735026918962629 0.57735026918962573];
smiData.RigidTransform(36).ID = 'F[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 -5.5000000000000053 0];  % mm
smiData.RigidTransform(37).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(37).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(37).ID = 'B[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [-26.899999999994424 18.050000000002633 24.999999999998636];  % mm
smiData.RigidTransform(38).angle = 2.0943951023931815;  % rad
smiData.RigidTransform(38).axis = [0.57735026918963528 -0.57735026918962096 0.57735026918962096];
smiData.RigidTransform(38).ID = 'F[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [0 120 -0.0010000000000010001];  % mm
smiData.RigidTransform(39).angle = 1.1102230246251563e-16;  % rad
smiData.RigidTransform(39).axis = [-0 -1 0];
smiData.RigidTransform(39).ID = 'B[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [3.2635227853461402e-11 -34.750000000000995 -1.9989999999993451];  % mm
smiData.RigidTransform(40).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(40).axis = [1 9.0860499991999664e-32 3.2717218774822011e-16];
smiData.RigidTransform(40).ID = 'F[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [-16.500000000000007 0 -3.5000000000000031];  % mm
smiData.RigidTransform(41).angle = 2.2204460492503136e-16;  % rad
smiData.RigidTransform(41).axis = [1 0 0];
smiData.RigidTransform(41).ID = 'B[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-22.999999998509388 18.050000000000118 16.499999999999396];  % mm
smiData.RigidTransform(42).angle = 2.0943951023931926;  % rad
smiData.RigidTransform(42).axis = [0.57735026918962873 0.57735026918962495 -0.57735026918962351];
smiData.RigidTransform(42).ID = 'F[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-5.0000000000000044 12.071067811865511 0];  % mm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [-5.2999999999981 67.07106781186539 5.5000000000000284];  % mm
smiData.RigidTransform(44).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(44).axis = [0.57735026918962584 -0.57735026918962551 0.57735026918962606];
smiData.RigidTransform(44).ID = 'F[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [13.799999999999965 52.999999999999993 5.4999999999999636];  % mm
smiData.RigidTransform(45).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(45).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(45).ID = 'B[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [-13.799999999997087 26.050000000000427 1.4495071809506044e-12];  % mm
smiData.RigidTransform(46).angle = 2.0943951023931913;  % rad
smiData.RigidTransform(46).axis = [0.57735026918962806 0.57735026918962395 -0.57735026918962529];
smiData.RigidTransform(46).ID = 'F[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [0 0 0];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(47).ID = 'B[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [-1.0263147286329105e-11 -85.999999999999972 7.4449717359210012e-13];  % mm
smiData.RigidTransform(48).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(48).axis = [-0.57735026918962595 -0.57735026918962573 -0.57735026918962562];
smiData.RigidTransform(48).ID = 'F[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-22.02703480841592 4.1028125691227597 80.063572190701933];  % mm
smiData.RigidTransform(49).angle = 0;  % rad
smiData.RigidTransform(49).axis = [0 0 0];
smiData.RigidTransform(49).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-140.65528607065161 -154.44236698097052 81.593161145651123];  % mm
smiData.RigidTransform(50).angle = 0;  % rad
smiData.RigidTransform(50).axis = [0 0 0];
smiData.RigidTransform(50).ID = 'RootGround[Part1-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.0071285815431194289;  % kg
smiData.Solid(1).CoM = [-0.42843487706856681 12.510643062129502 0];  % mm
smiData.Solid(1).MoI = [0.45814644939764348 0.42765081401936339 0.70781861394704559];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 0.035781849855651131];  % kg*mm^2
smiData.Solid(1).color = [0.12156862745098039 0.25490196078431371 1];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Servo Motor Micro  9g*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.033876630295594158;  % kg
smiData.Solid(2).CoM = [-0.4903219124128308 20.358074512903947 -1.2918440697688045e-06];  % mm
smiData.Solid(2).MoI = [5.8482510929244169 6.0274552077711148 9.5878080593298538];  % kg*mm^2
smiData.Solid(2).PoI = [6.4718830448115649e-07 1.567238968991086e-07 0.27277211248685718];  % kg*mm^2
smiData.Solid(2).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Servo Motor MG996R_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.00079876241318469084;  % kg
smiData.Solid(3).CoM = [15.500000000000007 2 0];  % mm
smiData.Solid(3).MoI = [0.0036325042236300983 0.10442422565960366 0.10292175453779941];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'grip link 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0026416132846297431;  % kg
smiData.Solid(4).CoM = [-4.5275913705687669 2 -0.60196930727362141];  % mm
smiData.Solid(4).MoI = [0.090046111646969504 0.44723966749329935 0.36423785793867586];  % kg*mm^2
smiData.Solid(4).PoI = [0 -0.0092574084887821796 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'gear1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.0025658596693438518;  % kg
smiData.Solid(5).CoM = [-15.802287599926878 2 0.13999953130627879];  % mm
smiData.Solid(5).MoI = [0.096871414429773955 0.44616255154541518 0.35613342956722488];  % kg*mm^2
smiData.Solid(5).PoI = [0 0.044672222615650264 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'gear2_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.0053974701398930717;  % kg
smiData.Solid(6).CoM = [4.2500225915138357 9.5131476517421962 -31.889976021591902];  % mm
smiData.Solid(6).MoI = [1.7139108532223843 1.5958276983903421 0.18307767030588401];  % kg*mm^2
smiData.Solid(6).PoI = [0.37341188434821881 6.5121955707659532e-06 1.2431071757242153e-05];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Gripper 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.0157214039263101;  % kg
smiData.Solid(7).CoM = [15.976607329816053 -3.1832399913282656 -39.448867575183598];  % mm
smiData.Solid(7).MoI = [7.2474438601419839 8.1157623325169279 2.5604582617981966];  % kg*mm^2
smiData.Solid(7).PoI = [-1.3641301898784308 -1.4285481948392436 -0.35034739686203425];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Gripper base_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.064392689835693517;  % kg
smiData.Solid(8).CoM = [-0.13010640517118285 58.590055934236545 7.7687950238576207];  % mm
smiData.Solid(8).MoI = [110.15257046900956 9.2537956247527973 115.09551025859403];  % kg*mm^2
smiData.Solid(8).PoI = [0.13194957348981881 -0.022606570487793669 -0.66174652803562073];  % kg*mm^2
smiData.Solid(8).color = [0 0.25490196078431371 0.92156862745098034];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Arm 01*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.016499409121932894;  % kg
smiData.Solid(9).CoM = [0.045879907338241946 17.841068460271103 -5.2646318752902044];  % mm
smiData.Solid(9).MoI = [3.9122057893399451 2.6124399127947315 5.0223428677045492];  % kg*mm^2
smiData.Solid(9).PoI = [0.57578925685915316 -0.0039826478484937429 0.011582795799652899];  % kg*mm^2
smiData.Solid(9).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'Arm 03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.050268280661544686;  % kg
smiData.Solid(10).CoM = [0.027846765839261125 4.535306924267819 5.4088533654566078];  % mm
smiData.Solid(10).MoI = [54.600837585879745 9.2867708786792367 58.148972217615956];  % kg*mm^2
smiData.Solid(10).PoI = [-0.28753241094282822 -5.4544814798143254e-05 -0.069583656955222534];  % kg*mm^2
smiData.Solid(10).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'Arm 02 v3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.46387118068965899;  % kg
smiData.Solid(11).CoM = [0.00033070895600413315 51.365620594267369 -0.0006051376851412256];  % mm
smiData.Solid(11).MoI = [1400.6242624749955 2061.2568834285585 1473.1063207934212];  % kg*mm^2
smiData.Solid(11).PoI = [-0.013857222560410056 -0.0036016635968551146 0.0075729998638999632];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.068038308291964195;  % kg
smiData.Solid(12).CoM = [-6.4346174922233255 17.289415162555223 -1.3719889444740436];  % mm
smiData.Solid(12).MoI = [58.133187548494583 54.676389153981759 45.017727888450807];  % kg*mm^2
smiData.Solid(12).PoI = [6.2427453291760617 -0.64175688336673231 5.1776609631200294];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'Waist*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(6).Rz.Pos = 0.0;
smiData.CylindricalJoint(6).Pz.Pos = 0.0;
smiData.CylindricalJoint(6).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(1).Rz.Pos = -138.18379353878683;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.CylindricalJoint(2).Rz.Pos = 113.20130486398247;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-4]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = -113.94049920087222;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(4).Rz.Pos = 71.579285204873173;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[Gripper Assembly_r1-1:grip link 1_r1-2:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(5).Rz.Pos = 134.73188616660875;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(5).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(6).Rz.Pos = -45.268113833392057;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-2:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(1).Rz.Pos = 0.0;
smiData.PlanarJoint(1).Px.Pos = 0.0;
smiData.PlanarJoint(1).Py.Pos = 0.0;
smiData.PlanarJoint(1).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 108.61490159723068;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-3:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(11).Rz.Pos = 0.0;
smiData.RevoluteJoint(11).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 66.79869513601831;  % deg
smiData.RevoluteJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -138.18379353878987;  % deg
smiData.RevoluteJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-2]';

smiData.RevoluteJoint(3).Rz.Pos = -46.007308170281817;  % deg
smiData.RevoluteJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

smiData.RevoluteJoint(4).Rz.Pos = -130.74527440483863;  % deg
smiData.RevoluteJoint(4).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:gear2_r1-1]';

smiData.RevoluteJoint(5).Rz.Pos = -64.140766070921956;  % deg
smiData.RevoluteJoint(5).ID = '[Gripper Assembly_r1-1:gear2_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

smiData.RevoluteJoint(6).Rz.Pos = -71.579285204870175;  % deg
smiData.RevoluteJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.RevoluteJoint(7).Rz.Pos = -105.59918549321459;  % deg
smiData.RevoluteJoint(7).ID = '[Waist-1:-:Arm 01-1]';

smiData.RevoluteJoint(8).Rz.Pos = -153.98719342633399;  % deg
smiData.RevoluteJoint(8).ID = '[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(9).Rz.Pos = 127.42108026429133;  % deg
smiData.RevoluteJoint(9).ID = '[Arm 01-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(10).Rz.Pos = 15.911331883566504;  % deg
smiData.RevoluteJoint(10).ID = '[Arm 03-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(11).Rz.Pos = 124.91931808943036;  % deg
smiData.RevoluteJoint(11).ID = '[Part1-1:-:Waist-1]';

