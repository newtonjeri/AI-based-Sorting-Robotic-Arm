% Simscape(TM) Multibody(TM) version: 7.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(50).translation = [0.0 0.0 0.0];
smiData.RigidTransform(50).angle = 0.0;
smiData.RigidTransform(50).axis = [0.0 0.0 0.0];
smiData.RigidTransform(50).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [31 4 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [12.999999995191418 7.5805406396511898e-10 -4.9999999953509473];  % mm
smiData.RigidTransform(2).angle = 2.094395102393209;  % rad
smiData.RigidTransform(2).axis = [0.57735026918963051 -0.57735026918961396 0.57735026918963295];
smiData.RigidTransform(2).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [31.000000003874554 9.0000000000089795 4.3678696215465607e-09];  % mm
smiData.RigidTransform(4).angle = 2.0943951023932135;  % rad
smiData.RigidTransform(4).axis = [0.57735026918963173 -0.57735026918962684 0.57735026918961863];
smiData.RigidTransform(4).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [23 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [31.000000003909648 -3.4999999999831322 4.3873349397927086e-09];  % mm
smiData.RigidTransform(6).angle = 2.0943951023932135;  % rad
smiData.RigidTransform(6).axis = [0.57735026918963184 -0.57735026918962762 0.57735026918961785];
smiData.RigidTransform(6).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [13 4.9999999999999991 -5.0000000000000044];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [31.000000005308706 7.5000000007566499 -4.0836134473920538e-09];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931788;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962029 -0.57735026918962018 -0.57735026918963683];
smiData.RigidTransform(8).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-10.106342553831125 4 0];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [5.0000000046436881 12.500000000744359 -25.000000006547452];  % mm
smiData.RigidTransform(10).angle = 2.0943951023932099;  % rad
smiData.RigidTransform(10).axis = [0.57735026918963051 -0.57735026918961363 0.57735026918963306];
smiData.RigidTransform(10).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-39.571310364689879 4.0000000008615837 -32.672260702109398];  % mm
smiData.RigidTransform(12).angle = 1.9888452184490719;  % rad
smiData.RigidTransform(12).axis = [-0.64999786195497011 0.5373559246225772 0.5373559246225752];
smiData.RigidTransform(12).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [20.643657446168888 3.9999999999999964 0];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-3.9999999999684888 4.9999999679203988 -4.9999999849944974];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931873;  % rad
smiData.RigidTransform(14).axis = [0.57735026918962673 0.57735026918962284 0.57735026918962762];
smiData.RigidTransform(14).ID = 'F[Gripper Assembly_r1:gear1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [31.899999999999999 0 -24.999999999999993];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-10.106342549084815 -8.499999999883455 3.2595934840173868e-09];  % mm
smiData.RigidTransform(16).angle = 2.0943951023932135;  % rad
smiData.RigidTransform(16).axis = [0.57735026918963173 -0.57735026918962895 0.57735026918961674];
smiData.RigidTransform(16).ID = 'F[Gripper Assembly_r1:Gripper base_r1-1:-:Gripper Assembly_r1:gear2_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-40.593272041075799 0 4.01368041076661];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [8.4999999991215756 4.9999999995020641 -5.0000000053596345];  % mm
smiData.RigidTransform(18).angle = 2.0943951023932033;  % rad
smiData.RigidTransform(18).axis = [0.5773502691896264 0.5773502691896284 0.57735026918962251];
smiData.RigidTransform(18).ID = 'F[Gripper Assembly_r1:gear2_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 4 0];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-7.709326510507708e-10 4.9999999989774953 -27.000000005292165];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931935;  % rad
smiData.RigidTransform(20).axis = [-0.57735026918962218 -0.57735026918962529 0.57735026918962984];
smiData.RigidTransform(20).ID = 'F[Gripper Assembly_r1:grip link 1_r1-2:-:Gripper Assembly_r1:Gripper 1_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [8.5 4.9999999999999973 -26.999999999999996];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [3.9399938488317808e-09 7.788596434465331e-10 3.7347945324075607e-09];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931899;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962395 -0.57735026918963062 0.57735026918962273];
smiData.RigidTransform(22).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-1:-:Gripper Assembly_r1:grip link 1_r1-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 4 0];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [8.5000000000183284 4.9999999808712978 -26.999999991710176];  % mm
smiData.RigidTransform(24).angle = 2.0943951023931873;  % rad
smiData.RigidTransform(24).axis = [0.5773502691896264 0.57735026918962284 0.57735026918962806];
smiData.RigidTransform(24).ID = 'F[Gripper Assembly_r1:grip link 1_r1-1:-:Gripper Assembly_r1:Gripper 1_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [8.5 5.0000000000000044 -26.999999999999996];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-1.6933416305850148e-08 12.499999999980274 1.2145417580748832e-08];  % mm
smiData.RigidTransform(26).angle = 2.0943951023932019;  % rad
smiData.RigidTransform(26).axis = [0.57735026918962784 -0.57735026918962185 0.57735026918962762];
smiData.RigidTransform(26).ID = 'F[Gripper Assembly_r1:Gripper 1_r1-2:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [0 4 0];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [2.9426758763267706 7.7385800582554234e-10 -19.370034876600339];  % mm
smiData.RigidTransform(28).angle = 2.094395102393197;  % rad
smiData.RigidTransform(28).axis = [0.5773502691896264 -0.57735026918962673 0.57735026918962418];
smiData.RigidTransform(28).ID = 'F[Gripper Assembly_r1:grip link 1_r1-3:-:Gripper Assembly_r1:grip link 1_r1-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [0 0 11.000000000000004];  % mm
smiData.RigidTransform(29).angle = 0;  % rad
smiData.RigidTransform(29).axis = [0 0 0];
smiData.RigidTransform(29).ID = 'B[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [24.499999999739011 31.199999998688774 2.019518774432072e-09];  % mm
smiData.RigidTransform(30).angle = 2.0943951023932006;  % rad
smiData.RigidTransform(30).axis = [0.57735026918962162 0.57735026918962751 -0.57735026918962828];
smiData.RigidTransform(30).ID = 'F[Arm 02 v3-1:-:Servo Motor MG996R_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-18.000000000000004 0 0];  % mm
smiData.RigidTransform(31).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(31).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(31).ID = 'B[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-28.071642444848745 31.200000000000017 18.637902064602741];  % mm
smiData.RigidTransform(32).angle = 1.7177715174584078;  % rad
smiData.RigidTransform(32).axis = [0.86285620946101149 0.3574067443365998 -0.35740674433659952];
smiData.RigidTransform(32).ID = 'F[Waist-1:-:Servo Motor MG996R_r1-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [-48.501000000000019 40.276480175933123 -13.918506301988625];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(33).ID = 'B[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [7.1835870585346129e-12 9.8658858860289911e-12 -44.500999999999848];  % mm
smiData.RigidTransform(34).angle = 2.4708698718685164e-16;  % rad
smiData.RigidTransform(34).axis = [-0.32689630179883505 -0.94506021388599626 3.8167117845464896e-17];
smiData.RigidTransform(34).ID = 'F[Waist-1:-:Arm 01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [0 27.999999998507775 -13.999999999999984];  % mm
smiData.RigidTransform(35).angle = 0;  % rad
smiData.RigidTransform(35).axis = [0 0 0];
smiData.RigidTransform(35).ID = 'B[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [5.9999999999713536 -9.0000000009422365 -62.999999997120597];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(36).axis = [-0.57735026918962562 -0.57735026918962562 0.57735026918962595];
smiData.RigidTransform(36).ID = 'F[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [0 -5.5000000000000329 0];  % mm
smiData.RigidTransform(37).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(37).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(37).ID = 'B[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [-26.899999999869216 18.050000000234956 25.000000000001862];  % mm
smiData.RigidTransform(38).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(38).axis = [0.57735026918962606 -0.57735026918962551 0.57735026918962562];
smiData.RigidTransform(38).ID = 'F[Gripper Assembly_r1-1:Gripper base_r1-1:-:Servo Motor Micro  9g-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [0 120.00000000000001 -0.00099999999999406119];  % mm
smiData.RigidTransform(39).angle = 0;  % rad
smiData.RigidTransform(39).axis = [0 0 0];
smiData.RigidTransform(39).ID = 'B[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [1.1807355093651495e-09 -34.749999999857224 -1.999000016640462];  % mm
smiData.RigidTransform(40).angle = 3.1415926535897025;  % rad
smiData.RigidTransform(40).axis = [-1 1.5973849012760169e-26 -3.5220739459228729e-13];
smiData.RigidTransform(40).ID = 'F[Arm 01-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [-16.5 0 -3.5000000000000031];  % mm
smiData.RigidTransform(41).angle = 1.0061396160665481e-16;  % rad
smiData.RigidTransform(41).axis = [1 0 0];
smiData.RigidTransform(41).ID = 'B[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-22.999999998672703 18.04999999995762 16.499999999999865];  % mm
smiData.RigidTransform(42).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(42).axis = [0.57735026918962529 0.57735026918962606 -0.57735026918962595];
smiData.RigidTransform(42).ID = 'F[Arm 03-1:-:Servo Motor Micro  9g-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-5.0000000000000044 12.071067811865483 0];  % mm
smiData.RigidTransform(43).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(43).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(43).ID = 'B[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [-5.2999999998383256 67.071067811883992 5.4999999814041267];  % mm
smiData.RigidTransform(44).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(44).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(44).ID = 'F[Arm 03-1:-:Arm 02 v3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [13.799999999999979 53.000000000000021 5.5000000000000053];  % mm
smiData.RigidTransform(45).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(45).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(45).ID = 'B[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [-13.799999999999901 26.050000000223584 4.5903902901045512e-10];  % mm
smiData.RigidTransform(46).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(46).axis = [0.5773502691896264 0.57735026918962562 -0.5773502691896254];
smiData.RigidTransform(46).ID = 'F[Arm 02 v3-1:-:Servo Motor Micro  9g-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [0 0 0];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(47).ID = 'B[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [-1.1700725852684679e-14 -85.999999999999986 -8.0648252465193246e-15];  % mm
smiData.RigidTransform(48).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(48).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(48).ID = 'F[Part1-1:-:Waist-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-22.027034808415948 4.1028125691227881 80.063572190701976];  % mm
smiData.RigidTransform(49).angle = 0;  % rad
smiData.RigidTransform(49).axis = [0 0 0];
smiData.RigidTransform(49).ID = 'AssemblyGround[Gripper Assembly_r1-1:Gripper base_r1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-140.65528607065161 -154.44236698097052 81.593161145651123];  % mm
smiData.RigidTransform(50).angle = 0;  % rad
smiData.RigidTransform(50).axis = [0 0 0];
smiData.RigidTransform(50).ID = 'RootGround[Part1-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(12).mass = 0.0;
smiData.Solid(12).CoM = [0.0 0.0 0.0];
smiData.Solid(12).MoI = [0.0 0.0 0.0];
smiData.Solid(12).PoI = [0.0 0.0 0.0];
smiData.Solid(12).color = [0.0 0.0 0.0];
smiData.Solid(12).opacity = 0.0;
smiData.Solid(12).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.00079876241318469084;  % kg
smiData.Solid(1).CoM = [15.500000000000007 2 0];  % mm
smiData.Solid(1).MoI = [0.0036325042236300983 0.10442422565960366 0.10292175453779941];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'grip link 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.0025658596693438522;  % kg
smiData.Solid(2).CoM = [-15.802287599926878 2 0.13999953130627876];  % mm
smiData.Solid(2).MoI = [0.096871414429773928 0.44616255154541518 0.35613342956722488];  % kg*mm^2
smiData.Solid(2).PoI = [0 0.044672222615650244 0];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'gear2_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0157214039263101;  % kg
smiData.Solid(3).CoM = [15.976607329816053 -3.1832399913282656 -39.448867575183598];  % mm
smiData.Solid(3).MoI = [7.2474438601419839 8.1157623325169279 2.5604582617981957];  % kg*mm^2
smiData.Solid(3).PoI = [-1.3641301898784315 -1.4285481948392438 -0.35034739686203437];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Gripper base_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0053974701398930717;  % kg
smiData.Solid(4).CoM = [4.2500225915138357 9.5131476517421962 -31.889976021591902];  % mm
smiData.Solid(4).MoI = [1.7139108532223843 1.5958276983903421 0.18307767030588401];  % kg*mm^2
smiData.Solid(4).PoI = [0.37341188434821881 6.5121955707659532e-06 1.2431071757242153e-05];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Gripper 1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.0026416132846297426;  % kg
smiData.Solid(5).CoM = [-4.5275913705687669 2 -0.60196930727362163];  % mm
smiData.Solid(5).MoI = [0.090046111646969504 0.44723966749329935 0.3642378579386758];  % kg*mm^2
smiData.Solid(5).PoI = [0 -0.0092574084887821761 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'gear1_r1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.050268280661544699;  % kg
smiData.Solid(6).CoM = [0.02784676583926125 4.5353069242678172 5.4088533654566069];  % mm
smiData.Solid(6).MoI = [54.600837585879745 9.2867708786792367 58.148972217615942];  % kg*mm^2
smiData.Solid(6).PoI = [-0.28753241094282794 -5.4544814798145578e-05 -0.069583656955222187];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Arm 02 v3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.068038308291964195;  % kg
smiData.Solid(7).CoM = [-6.4346174922233255 17.289415162555223 -1.3719889444740436];  % mm
smiData.Solid(7).MoI = [58.133187548494583 54.676389153981745 45.017727888450807];  % kg*mm^2
smiData.Solid(7).PoI = [6.2427453291760617 -0.64175688336673276 5.1776609631200285];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Waist*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.46387118068965888;  % kg
smiData.Solid(8).CoM = [0.00033070895600093773 51.365620594267369 -0.00060513768513907173];  % mm
smiData.Solid(8).MoI = [1400.624262474995 2061.256883428558 1473.106320793421];  % kg*mm^2
smiData.Solid(8).PoI = [-0.013857222560406694 -0.0036016635968551132 0.0075729998638905281];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'Part1*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.0071285815431194298;  % kg
smiData.Solid(9).CoM = [-0.42843487706856676 12.510643062129503 0];  % mm
smiData.Solid(9).MoI = [0.45814644939764348 0.4276508140193635 0.70781861394704559];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 0.035781849855651117];  % kg*mm^2
smiData.Solid(9).color = [0.12156862745098039 0.25490196078431371 1];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'Servo Motor Micro  9g*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.064392689835693503;  % kg
smiData.Solid(10).CoM = [-0.13010640517118166 58.590055934236545 7.7687950238576189];  % mm
smiData.Solid(10).MoI = [110.15257046900956 9.2537956247527955 115.09551025859403];  % kg*mm^2
smiData.Solid(10).PoI = [0.13194957348982062 -0.022606570487794277 -0.66174652803562228];  % kg*mm^2
smiData.Solid(10).color = [0 0.25490196078431371 0.92156862745098034];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'Arm 01*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.01649940912193289;  % kg
smiData.Solid(11).CoM = [0.045879907338242154 17.841068460271099 -5.2646318752902053];  % mm
smiData.Solid(11).MoI = [3.912205789339946 2.612439912794732 5.0223428677045492];  % kg*mm^2
smiData.Solid(11).PoI = [0.57578925685915328 -0.003982647848493762 0.011582795799652882];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'Arm 03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.033876630295594158;  % kg
smiData.Solid(12).CoM = [-0.4903219124128308 20.358074512903947 -1.2918440697670353e-06];  % mm
smiData.Solid(12).MoI = [5.8482510929244178 6.0274552077711139 9.587808059329852];  % kg*mm^2
smiData.Solid(12).PoI = [6.4718830446488954e-07 1.5672389690248164e-07 0.27277211248685734];  % kg*mm^2
smiData.Solid(12).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'Servo Motor MG996R_r1*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(6).Rz.Pos = 0.0;
smiData.CylindricalJoint(6).Pz.Pos = 0.0;
smiData.CylindricalJoint(6).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(1).Rz.Pos = -99.414012568530097;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.CylindricalJoint(2).Rz.Pos = 98.386804509781555;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-4]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(3).Rz.Pos = -99.269790631903064;  % deg
smiData.CylindricalJoint(3).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(4).Rz.Pos = 32.64106215552016;  % deg
smiData.CylindricalJoint(4).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(4).ID = '[Gripper Assembly_r1-1:grip link 1_r1-2:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(5).Rz.Pos = 149.07719171548484;  % deg
smiData.CylindricalJoint(5).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(5).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(6).Rz.Pos = -30.922808284515064;  % deg
smiData.CylindricalJoint(6).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-2:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the PlanarJoint structure array by filling in null values.
smiData.PlanarJoint(1).Rz.Pos = 0.0;
smiData.PlanarJoint(1).Px.Pos = 0.0;
smiData.PlanarJoint(1).Py.Pos = 0.0;
smiData.PlanarJoint(1).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.PlanarJoint(1).Rz.Pos = 162.19918292168836;  % deg
smiData.PlanarJoint(1).Px.Pos = 0;  % mm
smiData.PlanarJoint(1).Py.Pos = 0;  % mm
smiData.PlanarJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-3:-:Gripper Assembly_r1-1:grip link 1_r1-4]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(11).Rz.Pos = 0.0;
smiData.RevoluteJoint(11).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 81.613195490218331;  % deg
smiData.RevoluteJoint(1).ID = '[Gripper Assembly_r1-1:grip link 1_r1-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(2).Rz.Pos = -99.414012568529856;  % deg
smiData.RevoluteJoint(2).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-2]';

smiData.RevoluteJoint(3).Rz.Pos = -31.80579440663659;  % deg
smiData.RevoluteJoint(3).ID = '[Gripper Assembly_r1-1:gear1_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-2]';

smiData.RevoluteJoint(4).Rz.Pos = -91.568848962197734;  % deg
smiData.RevoluteJoint(4).ID = '[Gripper Assembly_r1-1:Gripper base_r1-1:-:Gripper Assembly_r1-1:gear2_r1-1]';

smiData.RevoluteJoint(5).Rz.Pos = -24.795898549188035;  % deg
smiData.RevoluteJoint(5).ID = '[Gripper Assembly_r1-1:gear2_r1-1:-:Gripper Assembly_r1-1:Gripper 1_r1-1]';

smiData.RevoluteJoint(6).Rz.Pos = -32.641062155520437;  % deg
smiData.RevoluteJoint(6).ID = '[Gripper Assembly_r1-1:Gripper 1_r1-1:-:Gripper Assembly_r1-1:grip link 1_r1-3]';

smiData.RevoluteJoint(7).Rz.Pos = -65.524543803003368;  % deg
smiData.RevoluteJoint(7).ID = '[Waist-1:-:Arm 01-1]';

smiData.RevoluteJoint(8).Rz.Pos = 120.60186613643664;  % deg
smiData.RevoluteJoint(8).ID = '[Arm 03-1:-:Gripper Assembly_r1-1:Gripper base_r1-1]';

smiData.RevoluteJoint(9).Rz.Pos = 162.84615702868152;  % deg
smiData.RevoluteJoint(9).ID = '[Arm 01-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(10).Rz.Pos = 68.817402651143581;  % deg
smiData.RevoluteJoint(10).ID = '[Arm 03-1:-:Arm 02 v3-1]';

smiData.RevoluteJoint(11).Rz.Pos = 124.57688541855917;  % deg
smiData.RevoluteJoint(11).ID = '[Part1-1:-:Waist-1]';

